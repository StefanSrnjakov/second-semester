#include "tree_node.h"

TreeNode::TreeNode(size_t start, size_t stop, bool xy_flag)
    : start_(start)
    , stop_(stop)
    , xy_flag_(xy_flag)
{
} 