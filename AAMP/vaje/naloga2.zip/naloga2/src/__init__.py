"""
Linear regression package.
""" 